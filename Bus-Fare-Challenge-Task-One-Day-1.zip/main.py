#Importing the relevant library
from datetime import date

#1.	Gets today's date and stores it in a variable 'date'
date = date.today()
print("Date:", date)

#Uses today's date to get the name on the day of the week written in short form with the first letter capitalized eg. 'Fri' if today were Friday and assigns it a variable 'day'
day = date.strftime('%a')
print("Day:", day)

#Uses if statements to determine the today's fare following these bus fare schedule:
#Monday - Friday --> 100
#Saturday --> 60
#Sunday --> 80
#x is a variable used to store the week no
x = date.today().weekday()

if x < 5:#0-4 is Mon to Fri
    print ("Fare:", 100)
elif x == 5: #5 Sat
    print ("Fare:", 60)
else:  #6 Sun
    print ("Fare:", 80)

#Date: 2022-07-05
#Day: Tue
#Fare: 100

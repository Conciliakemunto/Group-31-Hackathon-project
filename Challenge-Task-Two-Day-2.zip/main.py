#career_list
Careers=["Medicine","Engineering","Hospitality","Business management","software developer","web developer"]
Caree_advices=["For one to do any cause you have to have passion","The courses available for one to do them one has to have passed mathematics","For one to do medicine they have to have passed biology"]
Career_questions=["Do you have passion?","did you pass mathematics?"]
karia=input("Which career do you wish to do?")
If karia!==career:
    Print("error")
Else:
    print(career_advice)
    if karia=="medicine":
        print ("answer yes or no")
    X=input ("did you pass biology?")
    X1=input ("did you pass mathematics?")
    X2=input ("do you have a passion in medicine?")
        if X&X1&X2 !=="yes","no":
            print ("error")
        elif X1&X2&X =="yes":
            print ("you qualify to do medicine!!")
        else:
            print ("you do not qualify ")
            end
else:
    Print ("answer yes or no")
    Y=input ("Do you have passion in the selected career?")
    Y1=input ("Did you pass mathematics?")
    If Y&Y1 !== "yes","no":
        print ("error")
    elifY&Y1=="yes":
        print ("You qualify to do",karia)
    else:
        print ("You do not qualify to do",karia)
          end



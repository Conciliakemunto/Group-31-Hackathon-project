#We begin by importing the relevant libraries.
#We need datetime library to print when the door was last opened or closed.
import datetime 

Date = datetime.datetime.today() - datetime.timedelta()
#We store our password in a variable named password 
#Our password is set to admin
password = "admin"
#We then declare the following variables
open = "open"
close = "close"
quit = "quit"